import React, { useContext, useState, useEffect } from 'react'
import { QuizContext } from '../context/QuizHolder';
import ProgressBar from 'react-bootstrap/ProgressBar';

import clsx from 'clsx';
import "./main.css";
import Results from './Result';
const Home = () => {
    const { now, setNow, quiz, setquiz, loadCart, showResult, setShowResult, showresultdiv, setshowresultdiv, btnvalue, score, setScore, setbtnvalue, isActive, setActive, clickedOption, setClickedOption, QuizData, currentQuestion, setCurrentQuestion, disabl, setdisable } = useContext(QuizContext);

    useEffect(() => {
        setquiz(quiz);

        loadCart();

    }, [loadCart]);
    const alphabet = ['A', 'B', 'C', 'D'];
    const add = (i) => {
        setdisable(false);
        setClickedOption(i + 1);
        setActive(!isActive);
        setbtnvalue('Continue');
        if (currentQuestion == quiz.length - 1) {
            setbtnvalue('Finish');
        }
        else if (currentQuestion > quiz.length) {
            setbtnvalue('OKAY');
        }
        setActive(0);
    };
    const resetAll = () => {
        setShowResult(false);
        setCurrentQuestion(0);
        setClickedOption(0);
        setScore(0);
        setbtnvalue('Okay');
    };
    return (
        <div className="mt-6">
            {showResult ? (
                <Results score={score} totalScore={quiz.length} tryAgain={resetAll} />
            ) : (
                <div className='mt-6'>
                    <div className='top-div'>
                        <h3>{quiz.length}</h3>
                        <h1 className="text-center mt-5 mb-3 header1">Fantasy Quiz #156</h1>
                        <h4>X</h4>
                    </div>
                    <div className='div-width2'>
                        <ProgressBar now={now} label={`${now}%`} />

                        <span >
                            {currentQuestion + 1}
                            /
                            {quiz.length}
                        </span>
                    </div>
                    <div className="question">

                        <h1 className="text-center header2 mt-5">{quiz[currentQuestion]?.question}</h1>
                    </div>
                    <div className="option-container mt-2">

                        <ol className="">
                            {quiz[currentQuestion]?.options.map((option, i) => (

                                <li
                                    className={clsx('option-btn', { ['checked']: clickedOption == i + 1 })}

                                    key={i}
                                    onClick={() => add(i)}
                                >
                                    <b className="option-btns">{alphabet[i]}</b>
                                    {' '}
                                    <span>
                                        {' '}
                                        {option}
                                    </span>

                                </li>

                            ))}
                        </ol>
                    </div>

                    {
                        // Object.keys(quiz).map((item, index) => {
                        //     return (<>
                        //         <p>{quiz[item].question}</p>
                        //     </>)

                        // })
                    }    </div>

            )}






        </div >
    )
}

export default Home
