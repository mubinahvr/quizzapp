import React, { useState, useCallback, useMemo } from 'react'
import { createContext } from 'react'
import { QuizData } from '../data';
import axiosInstance from '../utils/axiosInstance';
const QuizContext = createContext();

export default function QuizHolder(props) {
    const [isActive, setActive] = useState('false');
    const [currentQuestion, setCurrentQuestion] = useState(0);
    const [disabl, setdisable] = useState(true);
    const [clickedOption, setClickedOption] = useState(0);
    const [btnvalue, setbtnvalue] = useState('Continue');
    const [score, setScore] = useState(0);
    const [showresultdiv, setshowresultdiv] = useState(false);
    const [showResult, setShowResult] = useState(false);
    const [quiz, setquiz] = useState([]);
    const [now, setNow] = useState(10);
    const loadCart = useCallback(async (data) => {

        try {

            const res = await axiosInstance.get('QuizData2');
            setquiz(res.data)

        } catch (err) {
        }
    }, []);

    const value = useMemo(
        () => ({
            quiz,
            setquiz,
            loadCart,
            showResult,
            setShowResult,
            showresultdiv,
            setshowresultdiv,
            score,
            setScore,
            btnvalue,
            setbtnvalue,
            isActive,
            setActive,
            clickedOption,
            setClickedOption,
            QuizData,
            currentQuestion,
            setCurrentQuestion,
            disabl,
            setdisable,
            now, setNow,
        }),
        [
            quiz,
            setquiz,
            loadCart,
            showResult,
            setShowResult,
            showresultdiv,
            setshowresultdiv,
            score,
            setScore,
            btnvalue,
            setbtnvalue,
            isActive,
            setActive,
            clickedOption,
            setClickedOption,
            QuizData,
            currentQuestion,
            setCurrentQuestion,
            disabl,
            setdisable,
            now, setNow,
        ],
    );
    return (
        <QuizContext.Provider value={value}>
            {props.children}

        </QuizContext.Provider >
    )
}

export { QuizContext };