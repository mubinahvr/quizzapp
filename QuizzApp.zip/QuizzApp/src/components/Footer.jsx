import React, { useContext, useState } from 'react'
import { QuizContext } from '../context/QuizHolder';
import ProgressBar from 'react-bootstrap/ProgressBar';
import "./main.css"

const Footer = () => {
    const { now, setNow, quiz, setquiz, showResult, setShowResult, showresultdiv, setshowresultdiv, score, setScore, btnvalue, setbtnvalue, isActive, setActive, QuizData, currentQuestion, setCurrentQuestion, clickedOption, setClickedOption, disabl, setdisable } = useContext(QuizContext);

    //const [isActive, setActive] = useState('false');

    //const [clickedOption, setClickedOption] = useState(0);
    const nextquestion = () => {
        updateScore();
        if (currentQuestion < quiz.length - 1) {
            setCurrentQuestion(currentQuestion + 1);
            setActive(!isActive);
            setClickedOption(0);
            setNow(now + 100 / quiz.length);
        } else {
            setbtnvalue('OKay')
            setShowResult(true);
            setshowresultdiv(true)
            setActive(!isActive);
            setbtnvalue('Continue');
            setNow(100 / QuizData.length);
            setbtnvalue('Continue');
        }
        if (currentQuestion >= quiz.length - 1) {
            setbtnvalue('OKay')
        }
        if (currentQuestion == quiz.length - 2) {
            setbtnvalue('Finish');

        }
    }
    const updateScore = () => {
        if (clickedOption === quiz[currentQuestion].answer) {
            setScore(score + 1);
        }
    };
    return (
        <div className="footer">
            <>{
                !showresultdiv ? (
                    <div className='div-width'>
                        <ProgressBar now={now} label={`${now}%`} />

                        <span >
                            {currentQuestion + 1}
                            /
                            {quiz.length}
                        </span>
                    </div>
                ) : ""}
                <div className={!showresultdiv ? 'change-btn' : 'change-btn2'}>
                    <button
                        className={isActive ? 'actionbtn' : 'actionbtn-ac'}
                        type="button"
                        onClick={nextquestion}
                        disabled={disabl}
                    >
                        {btnvalue}
                    </button>
                </div>



            </>
        </div>
    )
}

export default Footer
